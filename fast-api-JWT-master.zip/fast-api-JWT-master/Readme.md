Feature of FastApi

-> Automactic documentation - swagger UI
                            - ReDoc

-> Pydantic

-> Based on OpenAPI and json Schema

-> Security and authentication
    - JWT
    - HTTP Basic