DATA_DIR_NAME = 'data'
MODEL_DIR_PATH = 'models'

TRAIN_DATA_PATH = 'train.csv'
USER_DATA_PATH = 'user_data.csv'
MODEL_PATH = 'saved_model.pkl'